#include <stdio.h>
#include <stdlib.h>

int main(){
	
	float peixe_pescado, excedente, multa;
	
	
system("pause");
	
	printf("Insira a quantidade em quilogramas pescados: ");

		scanf("%f", &peixe_pescado);
		
		if (50.00 < peixe_pescado ){           //fazendo a condi��o da quantidade permitida para quantidade pescada
			
			excedente = peixe_pescado - 50;    //calculo para verificar a quantidade de Kg que ir� passar do valor permitido
			
			multa = excedente * 4;             //calculo para verificar a multa a ser cobrada pela quantidade de Kg permitida
			
			printf("Devera pagar uma multa de %2.f reais referente a taxa cobrada por excesso de KG", multa);
			printf("A quantidade de KG excedido eh de: %2.f", excedente);
		}
			else {
				
				printf("Voce nao sera taxado pela pesca, tenha um bom dia: ");
			}
	
	return 0;
}
