#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(){
	
	float num1, num2, produto, soma, raiz_soma, raiz_quadrada;
	
	
	printf("Insira um numero real: ");
	scanf("%f", &num1);
	
	printf("Insira outro numero real: ");
	scanf("%f", &num2);
	
		produto = (num1 * num2) * 2;           //calcular o dobro do produto dos numeros
		
			printf("O dobro do produto dos numeros eh: %2.f\n", produto);
	
		soma = (num1 * 3) + (num2 / 2);        //calcular a soma do triplo do primeiro numero mais a metade do segundo
	
			printf("A soma do triplo do primeiro numero com a metade do segundo numero eh: %2.f\n", soma);
	
		raiz_soma = num1 + num2;              //soma dos primeiros numeros para prosseguir o resultado em raiz quadrada
		
		raiz_quadrada = sqrt(raiz_soma);      // calculo da raiz dos dois numeros usando a fun��o pronta da biblioteca
		
			printf("A raiz quadrada da soma dos dois numeros eh: %2.f\n", raiz_quadrada);	
		
	return 0;
	
}
