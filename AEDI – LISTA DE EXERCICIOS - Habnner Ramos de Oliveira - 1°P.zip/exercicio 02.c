#include <stdio.h>
#include <stdlib.h>

int main(){
	
	float celsius, conversao;
	
	
	printf("Para fazer a conversao de temperatura, insira a temperatura desejada em celsius: ");
	scanf("%f", &celsius);
			
			system("pause");
		
	conversao = (celsius * 1.8) + 32;    //calculo de conversao das unidades
	
	printf("A conversao de celsius para fahrenheit eh:  %2.fF", conversao);
	
	return 0;
	
}
