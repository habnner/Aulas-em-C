#include <stdio.h>
#include <stdlib.h>

int main(){
	
	float tempo, velocidade_m, distancia, litros_totais, litros_i = 12.00;
	
	
system("pause");

	printf("Digite o tempo gasto da viagem em horas: ");
		
		scanf("%f", &tempo);
		
	printf("Digite a velocidade media da viagem em KM/h: ");
		
		scanf("%f", &velocidade_m);
		
	distancia = velocidade_m * tempo;              //calculo de distancia baseada na formula de velocidade media
	
	printf("A distancia foi de: %2.fkm\n", distancia);
	
	litros_totais = distancia / litros_i;         //calculo de litro baseado no Km/l e distancia
	
	printf("Foram gastos %2.f litros de combustivel na viagem", litros_totais);
	
	return 0;
}
