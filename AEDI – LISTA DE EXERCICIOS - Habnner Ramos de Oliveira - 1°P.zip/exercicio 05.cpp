#include <stdio.h>
#include <stdlib.h>

int main(){
	
	float valor_fabrica, carro_novo;
	
	float imposto = 0.45;
	float distribuidor = 0.28; 
	
	system("pause");
	
	printf("Insira o valor do carro em fabrica: ");
		
		scanf("%f", &valor_fabrica);
		
	carro_novo = valor_fabrica + (valor_fabrica * imposto);   //calculo para verificar o valor do carro mais o acrescimo do imposto.
	
	carro_novo = carro_novo + (carro_novo * distribuidor);    //calculo para verificar a tarifa do distribuidor depois do imposto incluso.
	
		printf("O valor total do veiculo sera de %f reais", carro_novo);

	return 0 ;
}
