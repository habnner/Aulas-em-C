#include <stdio.h>
#include <stdlib.h>

int main(){
	
	float lado, dobro, area;
	
	printf("Para efetuar o calculo da area do quadrado e o seu dobro, insira o lado do mesmo: ");
	scanf("%f", &lado);
	
	system("pause");                                   //pequena pausa para o usuario 
	
	area = lado * lado;                               //calculando a area proposta
	
	printf("A area do quadrado eh: %2.f\n", area);   //emiss�o da area em tela 
	
	dobro = area * 2;                               //calculando o dobro da area
	
	printf("O dobro da area eh: %2.f\n", dobro);   //emiss�o do dobro em tela
	
	return 0;
}
