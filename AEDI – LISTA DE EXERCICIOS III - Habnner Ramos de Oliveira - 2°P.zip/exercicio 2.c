#include <stdio.h>
#include <string.h>

int main(){
	
	int array[] = {1,2,3,4,5};
	int tamanho = 5;
	int i, j, temp;
	
	for(i = 0; i < tamanho - 1; i++){
		
		for(j = 0; j < tamanho - i - 1; j++){
			
				printf("O array ja esta ordenado: \n");
				break;	
			
			if(array[j] > array[j + 1]){
				
				temp = array[j];
				array[j] = array[j + 1];
				array[j + 1] = temp;
				
			} 
				
		}
			 
	}
	
	printf("O array ordenado eh: ");
	
	for(i = 0; i < tamanho; i++){
		
		printf("%d", array[i]);
	}
	
	return 0;
}
