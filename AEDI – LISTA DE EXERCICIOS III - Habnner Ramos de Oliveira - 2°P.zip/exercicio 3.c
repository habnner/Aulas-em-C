#include <stdio.h>

int main(){
	
	int array[5];
	int i, j, temp, arr;
	
	printf("Digite cinco numeros para o array:\n",arr);
	
	for(i = 0; i < 5; i++){
		
		scanf("%d", &array[i]);
	}
	
	for(i = 0; i < 5 - 1; i++){
		
		for(j = 0; j < 5 - i - 1; j++){
			
			if(array[j] < array[j + 1]){
				
				temp = array[j];
				array[j] = array[j + 1];
				array[j + 1] = temp;
			}
		}
	}
		printf("O array ordenado decrescente sera: \n");
	for(i = 0; i < 5; i++ ){
		
		printf("%d", array[i]);
	}
	
	return 0;
}
