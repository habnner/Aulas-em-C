#include <stdio.h>
#include <string.h>


int main(){
	
	char arr[100];
	char temp;
	int i, j, letras;
	
	printf("Insira algumas letras: ");
	scanf("%s", &arr);
	
	letras = strlen(arr);
	
	for(i = 0; i < letras - 1; i++){           //loop para percorrer o array
		
		for(j = 0; j < letras - i - 1; j++){         //loop para comparar elementos exterior
			
			if(arr[j] > arr[j + 1]){        //trocar elementos de posicao caso o primeiro seja maior que o proximo
				
				temp = arr[j];                //armazenar o array em uma variavel temporaria
				arr[j] = arr[j + 1];        // mover o array para o outro
				arr[j + 1] = temp;            //armazenar o valor na outra variavel
				
			}
		}
	}
	
	printf("O array ordenado sera: %s\n", arr);
	
	
	return 0;
}
