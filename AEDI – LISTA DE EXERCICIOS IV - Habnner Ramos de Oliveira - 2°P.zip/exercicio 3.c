#include <stdio.h>


int fibonacci(int n){
	
	if(n == 0){
		return 0;
		
	} else if (n == 1){
		return 1;
		
	} else {return fibonacci(n - 1) + fibonacci(n - 2);
	}
}

int main(){
	
	int numeros[] = {10, 20, 30, 40, 50};
	int tamanho = 5;
	
	for(int i = 0; i < tamanho; i++){
		
		int n = numeros[i];
	
	printf("Os termos da sequencia de fibonacci de %d eh: %d\n", n, fibonacci(n));
}
	return 0;
}
