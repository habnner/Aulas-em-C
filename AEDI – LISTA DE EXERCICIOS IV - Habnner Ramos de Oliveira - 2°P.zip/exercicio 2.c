#include <stdio.h>


void pa(int quantidade, int valor, int razao, int array[]){
	for(int i = 0; i < quantidade; i++){
		array[i] = valor + razao * i;
	}
}

void mostrar_array(int array[], int quantidade){
	printf("Esses sao os elementos da PA: \n");
	for(int i =0; i < quantidade; i++){
		printf("%d; ", array[i]);
	}	
		printf("\n");
}
int main(){
	
	int quantidade = 15, valor = 50;
	int razao = 2;
	int array_pa[70];
	
	pa(quantidade, valor, razao, array_pa);
	mostrar_array(array_pa, quantidade);
	
	return 0;
}
