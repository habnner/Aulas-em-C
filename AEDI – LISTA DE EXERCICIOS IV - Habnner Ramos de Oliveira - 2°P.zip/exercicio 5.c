#include <stdio.h>

int mcd(int a, int b){
	if(b == 0){
		return a;
	}
	return mcd(b, a % b);
}

int main(){
	
	int n1 = 5;
	int n2 = 10;
	int resultado;
	
	resultado = mcd(n1, n2);
	
	printf("O MCD de %d e %d eh: %d\n", n1, n2, resultado);
	
	return 0;
}
