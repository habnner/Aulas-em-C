#include <stdio.h>

float maiorNum(float a, float b, float c){
int maior = a;
	
	if(b > maior){
		maior = b;
	}
	if(c > maior){
		maior = c;
	}
	return maior;
}

int main(){
	
	float n1, n2, n3;
	float resultado;
	
	printf("Insira o primeiro numero: ");
	scanf("%f", &n1);
	
	printf("Insira o segundo numero: ");
	scanf("%f", &n2);
	
	printf("Insira o terceiro numero: ");
	scanf("%f", &n3);
	
	resultado = maiorNum(n1, n2, n3);
	
	printf("O maior numero eh: %2.f\n", resultado);
	
	return 0;
}
