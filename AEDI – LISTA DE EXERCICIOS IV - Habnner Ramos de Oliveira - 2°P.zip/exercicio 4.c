#include <stdio.h>
#define TAMANHO 20

int buscaBin(int lista[], int valorProcurado, int comeco, int final){
	
	if(comeco > final){
		return -1;
	}
	
	while(comeco <= final){
		int meio = (comeco + final) / 2;
		
		if(lista[meio] == valorProcurado){
			return meio;
		}
		else if(lista[meio] > valorProcurado){
			
		return buscaBin(lista, valorProcurado, comeco, meio - 1);
		}
		
		else {return buscaBin(lista, valorProcurado, meio + 1, final);
		}
	}
}

int main(){
	
	int lista[TAMANHO] = {2, 5, 6, 8, 10, 12, 13, 15, 16, 18, 19, 20, 21, 22, 24, 25, 26, 28, 29, 30};
	int valorProcurado, resultado;
	
	printf("Digite o valor a ser buscado: ");
	scanf("%d", &valorProcurado);
	
	resultado = buscaBin(lista, valorProcurado, 0, TAMANHO - 1);
	
	if(resultado != -1){
		printf("O valor encontrado no array eh: %d\n", resultado);
		
	} else {printf("Valor nao encontrado.\n");
	}
	
	return 0;
}
