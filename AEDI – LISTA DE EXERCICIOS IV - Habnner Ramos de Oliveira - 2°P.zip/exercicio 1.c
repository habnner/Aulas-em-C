#include <stdio.h>


int soma(int n){
	
	if(n == 1){
		return 1;
		
	} else {return n+ soma(n-1);
		
	}
}
int main(){
	
	int numeros[] = {2, 4, 6, 8, 10};
	int tamanho = 5;
	
	for(int i = 0; i < tamanho; i++){
		
		int n = numeros[i];
		
	printf("A soma dos valores de 1 a %d eh: %d\n", n, soma(n));	
	}
	
	return 0;
}
