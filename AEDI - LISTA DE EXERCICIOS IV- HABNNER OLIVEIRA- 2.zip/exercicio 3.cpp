#include <stdio.h>

int main()
{
    int valor;
    float preco[valor];
    int j, chave, x;
 
    printf("Insira no maximo 20 pre�os desejados: ");
    scanf("%d", &valor);
    
    for(int j = 0; j < valor; j++){
        
        printf("Digite o preco desejado %d: ", j + 1);
        scanf("%f", &preco[j]);
    }
    
    for(int j = 0; j < valor; j++){
    	chave = preco[j];
    	x = j - 1;
    	
    while(x >= 0 && preco[x] > chave){
    	preco[x + 1] = preco[x];
		x--; 
	}	
	
	preco[x + 1] = chave;	
}
    printf("Os valores escolhidos sao:\n");
    
    for(int j = 0; j < valor; j++){
        
        printf("%2.f\n", preco[j]);
    }
    return 0;
}
