#include <stdio.h>

int main()
{
    int inteiro;
    int controle;
    
    printf("Insira um numero inteiro positivo: ");
    scanf("%d", &inteiro);
    
    for(int controle = 2; controle <= inteiro; controle += 2 ){
        
        printf("%d", controle);
        
    if(controle + 2 <= inteiro){
        
        printf(" ");
    }    
}    
    
    return 0;
}
