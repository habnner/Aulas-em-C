#include <stdio.h>

int main() {
    int tamanho = 2; 
    int valores[tamanho]; 
    int buscar;
    int inicio = 0;
	int fim = tamanho -1;
	int meio;
    int encontrado = 0;


    printf("Insira um valor inteiro: ");
    scanf("%d", &valores[0]);
    
    printf("Insira o segundo valor inteiro: ");
    scanf("%d", &valores[1]);

    
    printf("Digite um valor para realizar a busca: ");
    scanf("%d", &buscar);
    
    while (inicio <= fim) {
        meio = (inicio + fim) / 2;

        if (valores[meio] == buscar) { 
            printf("O numero %d foi encontrado na posicao %d.\n", buscar, meio + 1);
            encontrado = 1;
            break;
        } else if (valores[meio] > buscar) {
            fim = meio - 1;
        } else {
            inicio = meio + 1;
        }
    }

    if (!encontrado) {
        printf("O numero %d nao foi encontrado na lista.\n", buscar);
    }

    return 0;
}

