#include <stdio.h>

int main()
{
    int idade;
    
    printf("Insira sua idade: ");
    scanf("%d",&idade);
    
    switch(idade){
        
        case 1 ... 17: 
        printf("Voce he Menor de idade!\n");
        
        break;
        
        case 18 ... 64:
        printf("Voce he Maior de idade!\n");
        break;
        
        default:
        printf("Voce j� est� no fim da vida, Idoso!\n");
        break;
    }
    
    return 0;
}
