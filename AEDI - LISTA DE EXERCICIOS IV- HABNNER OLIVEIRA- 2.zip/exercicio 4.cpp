#include <stdio.h>

int main(){
	
	int notas;
    float nota_total[notas];
    int j, controle, x;
 
    printf("Insira o numero de notas que deseja: ");
    scanf("%d", &notas);
    
    for(int j = 0; j < notas; j++){
        
        printf("Digite a nota %d: ", j + 1);
        scanf("%f", &nota_total[j]);
    }
    
	for(j = 0; j < notas; j ++){
		
		for(x = 0; x < notas - j - 1; x++){
			
			if(nota_total[x] < nota_total[x + 1]){
				controle = nota_total[x];
				nota_total[x] = nota_total[x + 1];
				nota_total[x +1] = controle;
			}
		}
	}
	
	printf("Notas ordenadas em decrescencia:\n");
	
	for(j = 0; j < notas; j++){
		printf("%2.f\n", nota_total[j]);
	}
	
	return 0;
}
