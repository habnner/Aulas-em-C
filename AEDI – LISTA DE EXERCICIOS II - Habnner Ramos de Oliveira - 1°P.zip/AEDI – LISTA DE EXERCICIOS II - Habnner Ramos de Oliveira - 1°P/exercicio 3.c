#include <stdio.h>

#define tamanho 100

int main(){
			int ativa;
			int contas;
			int inicio = 0;
			int comparacoes = 0;
			int encontrado = 0;
			int meio;
			int fim = tamanho - 1;
			int lista[tamanho] = {1, 2, 110, 4, 18, 6, 95, 8, 89, 10,                //depois que lembrei que poderia utilizar o "for" para gerar os numeros
11, 12, 13, 14, 15, 16, 17, 82, 19, 20,
21, 22, 23, 24, 25, 294, 27, 28, 29, 30,                   
31, 32, 218, 34, 35, 158, 37, 38, 187, 40,
41, 42, 43, 314, 45, 46, 47, 48, 49, 50,
51, 52, 354, 99, 55, 56, 57, 58, 59, 60,
61, 62, 321, 64, 65, 259, 67, 68, 69, 70,
71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
81, 54, 83, 84, 85, 86, 512, 88, 220, 90,
91, 92, 93, 94, 107, 96, 97, 98, 87, 100};
			
	printf("Insira um numero para ver se a conta est� ativa: ");
	scanf("%d", &ativa);
	
	while(inicio <= fim){
		
			meio = (inicio + fim) / 2;
		comparacoes ++;	
			
		if(lista[meio] == ativa) {
			
			printf("A conta %d foi encontrada na posicao %d.\n da lista", ativa, meio + 1);
			
			encontrado = 1;
		break;	
		}  else if(lista[meio] > ativa) {
			
			fim = meio - 1;
			}
				else {inicio = meio + 1;
			}
			
		} 
	if(!encontrado){
		
		printf("A conta referente a esse numero %d nao esta ativa.\n", ativa);
	}		

	printf("O numero de comparacoes foram: %d\n", comparacoes);

	return 0;
}
