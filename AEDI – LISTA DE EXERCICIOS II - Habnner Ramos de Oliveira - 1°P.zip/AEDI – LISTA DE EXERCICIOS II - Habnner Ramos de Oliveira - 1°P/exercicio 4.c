#include <stdio.h>

int main(){
	
	int primo[25];
	int contador = 0;
	int inicio = 0;
	int fim = primo - 1;
	int primos;
	int num_buscado;
	int encontrado = 0;
	int numer;
	int i = 0;
	int meio;
	
	for(int numer = 2; numer <= 100; i++){
		
		int primos = 1;
	}
	
	for(int i = 2; i * i <= numer; i++){
		
		if(numer % i == 0){
			
			primos = 0;
		break;	
		}
		
		if(primos){
			
			primo[contador] = numer;
		
		contador++;
		}
	}
	
	printf("Insira um numero de 1 a 100: ");
	scanf("%d", &num_buscado);
	
	while(inicio <= fim){
		
		meio = (inicio + fim) / 2;
		
	if(primo == num_buscado){
		
		printf("O numero informado est� na posicao %d.\n", meio + 1);
		encontrado = 1;
	break;	
		}
		
		else if(primo > num_buscado){
			fim = meio - 1;
		}	
		
		else{ inicio = meio + 1;
		}
		
	}
	
	return 0;
}
