#include <stdbool.h>
#include <stdio.h>
#define caractere 10
#define chances 2

int main(){
	
	char palavra[caractere +1 ];
	int vidas;
	char secreta[caractere + 1];
	char letra;
	int tamanho = 0;
	bool letra_encontrada;
	
	printf("Insira uma palavra de no maximo 10 caracteres para o jogo: ");
	fgets(palavra, sizeof(palavra), stdin);
	
	while (palavra[tamanho] != '\n' && palavra[tamanho] != '\0') {            //remover o caractere de nova linha
		
		tamanho++;
	}
	palavra[tamanho] = '\0';                                                //inserir o o caractere nulo
	
	vidas = tamanho + chances;                                             //calculo para o numero de vidas segundo a palavra
	
	for (int i = 0; < tamanho; i++){
		
		secreta[i] = '_';
	}
	secreta[tamanho] = '\n';
	
	while(vidas >0){
		
		bool palavra_encontrada = true;
		
		for(int i = 0; i < tamanho; i++){
			
			if(secreta[i] == '_') {
				
				palavra_encontrada = false;
				
			break;	
			}
		}
		
		if (palavra_encontrada){
			
			printf("Voce acertou a palavra: %s\n", palavra);
		
		break;	
		}
		
		printf("\nPalavra: %s\n", secreta);
		printf("Vidas restantes: %d\n", vidas);
			
			printf("Digite uma letra: ");
			scanf("%c", &letra);
			
		letra_encontrada = false;
		
		for(int i = 0; i < tamanho; i++){
			
			if(palavra[i] == letra){
				
				secreta[i] = letra;
			
			letra_encontrada = true;	 
			}
		}
		
		if(!letra_encontrada){
			
			vidas--;
			
		}
	}
	
		if(vidas <= 0){
			
			printf("Fim de jogo, suas vidas acabaram. A palavra correta e: %s\n", palavra);
			
		}
	
	return 0;
}
