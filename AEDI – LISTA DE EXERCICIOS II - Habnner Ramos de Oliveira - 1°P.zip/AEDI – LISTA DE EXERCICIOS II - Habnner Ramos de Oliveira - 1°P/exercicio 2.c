#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define nota_ruim 1
#define nota_boa 5

int main(){
	
	int criancas = 50;
	int lista[criancas];
	int contar[nota_boa + 1];
	
	srand(time(NULL));
	
	for(int i = 0; i < criancas; i++){
		
		lista[i] = rand() % (nota_boa - nota_ruim + 1) + nota_ruim;
	}
	
	for(int i = nota_ruim; i <= nota_boa; i++){
		
		contar[i] = 0;
	}
	
	for(int i = 0; i < criancas; i++){
		
		contar[lista[i]]++;
	}
	
	printf("Os resultados sao:\n");
	
	for(int i = nota_ruim; i < nota_boa; i++){
		
		printf("Nota %d: %d vezes\n", i, contar[i]);
	}
	
	return 0;
}
